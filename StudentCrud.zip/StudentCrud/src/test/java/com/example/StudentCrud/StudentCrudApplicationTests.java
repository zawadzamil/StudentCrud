package com.example.StudentCrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
